<?php

class DoctorController
{
	private function __construct()
	{
	}
	
	public function register()
	{
		
	}
}
