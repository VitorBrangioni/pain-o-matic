<?php

/**
 * 
 * @author vitor.brangioni
 *
 */
class Doctor extends Pojo
{
	private $name;
}