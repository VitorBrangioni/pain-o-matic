<?php

namespace model\interfaces;

interface ConnectionInterface
{
	public static function getInstance();
}